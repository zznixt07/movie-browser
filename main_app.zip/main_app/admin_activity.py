import configs
import user_activity
from sql_db.sql_connector import CredsDb

class AdminLogin(user_activity.UserLogin):

    def __init__(self, *args, **kwargs):
        user_activity.UserLogin.__init__(self)
        
    def goBack(self):
        try:
            # if a timeout exists, cancel it/ restart it
            configs.ROOT.after_cancel(self.intervalId)
        except AttributeError:
            pass
        self.destroy()
        import admin_win
        configs.ShowFrame(admin_win.AdminWin)

    def done(self):
        with CredsDb(tblName=configs.CREDSTABLE) as db:
            if not db.isAdmin(self.username.get()):
                self.showErr('Username or Password does not match')
                return
            userInfo = db.returnPersonInfo(self.username.get(), self.pswdEnt.get())
        
        if not userInfo:
            self.showErr('Username or Password does not match')
            return

        configs.CURRLOGGEDIN = userInfo['username']
        configs.USERID = userInfo['pId']
        configs.ISADMIN = True
        try:
            # if a timeout exists, cancel it/ restart it
            configs.ROOT.after_cancel(self.intervalId)
        except AttributeError:
            pass
            
        self.destroy()
        import admin_control
        configs.ShowFrame(admin_control.Control)


class AdminSignup(user_activity.UserSignup):

    def __init__(self, *args, **kwargs):
        user_activity.UserSignup.__init__(self, *args, admin=True, **kwargs)
        
    def goBack(self):
        self.destroy()
        try:
            # if a timeout exists, cancel it/ restart it
            configs.ROOT.after_cancel(self.intervalId)
        except AttributeError:
            pass
        import admin_win
        configs.ShowFrame(admin_win.AdminWin)


if __name__ == '__main__':
    configs.ROOT = configs.RootWin()
    configs.ROOT.attributes('-topmost', True)
    configs.ROOT.update()
    configs.ROOT.attributes('-topmost', False)
    configs.mainLogger()
    configs.ShowFrame(AdminLogin, geometry='1397x720-2+0')
    # configs.ShowFrame(AdminSignup, geometry='1397x720-2+0')
    configs.ROOT.mainloop()