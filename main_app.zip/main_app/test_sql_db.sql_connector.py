import unittest
from mysql.connector import errors
from sql_db import sql_connector
import logging

FORMAT = '%(levelname)s, %(message)s'
logging.basicConfig(level=logging.DEBUG, format=FORMAT)

allDict = {'imdbId': None, 'imgUrl': None, 'rating': None, 'totalRatedBy': None,
                'year': None, 'genres': None, 'isSeries': None,
                'start': None, 'end': None, 'epNum': None, 'szNum': None,
                'country': None, 'cast': None, 'plot': None, 'directors': None,
                'writers': None}
remDict = {'imdbId': None, 'imgUrl': None, 'rating': None}



class AppDbTestCase(unittest.TestCase):
    db = sql_connector.AppDb(tblName='test_table', create=True)

    # def setUp(self):
    #     self.db = sql_connector.AppDb(tblName='test_table')
    
    # def tearDown(self):
    #     self.db.close()

    def test_a_dropAllRows(self):
        print('dropping all rows')
        self.assertTrue(self.db.dropAllRows())

    def test_a_insertAllCols1(self):
        print('testing test_ainsertAllCols1')
        d = [{'title': 'test_movie1', **allDict}]
        result = self.db.insertAllCols(d)
        self.db.conn.commit()
        self.assertIs(result, True)

    def test_a_insertAllCols2(self):
        print('testing test_ainsertAllCols2')
        d = [{'title': 'test_movie1', **allDict}]
        fn = self.db.insertAllCols
        self.assertRaisesRegex(errors.IntegrityError, r'1062.+?Duplicate entry', fn, d)
    
    def test_cardsDictToSql1(self):
        print('testing test_cardsDictToSql1')
        d = [{'title': 'test_movie2', **remDict}]
        result = self.db.cardsDictToSql(d)
        self.db.conn.commit()
        self.assertTrue(result)
    
    def test_cardsDictToSql2(self):
        print('testing test_cardsDictToSql2')
        d = [{'title': 'test_movie2', **remDict}]
        result = self.db.cardsDictToSql(d)
        self.db.conn.commit()
        self.assertFalse(result)
        
    def test_dictFromTitle1(self):
        print('testing test_dictFromTitle1')
        result = self.db.dictFromTitle(title='test_movie1')
        self.assertTrue(result)

    def test_dictFromTitle2(self):
        print('testing test_dictFromTitle1')
        result = self.db.dictFromTitle(title='not_in_db_movie')
        self.assertIsNone(result)

    def test_getPage1(self):
        print('testing test_getPage1')
        result = self.db.getPage(page=1)
        self.assertTrue(result)
    
    def test_getPage2(self):
        print('testing test_getPage2')
        result = self.db.getPage(page=2)
        self.assertFalse(result)
        
    def test_titleExists1(self):
        print('testing test_titleExists1')
        result = self.db.titleExists(title='test_movie1')
        self.assertTrue(result)

    def test_titleExists2(self):
        print('testing test_titleExists2')
        result = self.db.titleExists(title='not_in_db_movie')
        self.assertFalse(result)


class CredsDbTestCase(unittest.TestCase):
    db = sql_connector.CredsDb(tblName='creds_test_table', create=True)

    def test_a_dropAllRows(self):
        print('dropping all rows')
        self.assertTrue(self.db.dropAllRows())

    def test_signupPerson(self):
        result = self.db.signupPerson({
                    'isAdmin': 0,
                    'username': 'test_uname',
                    'firstName': 'test_first',
                    'lastName': 'test_last',
                    'email': 'test_email',
                    'pswd': 'test_pass',
                    'gender': 'test_gender'})
        self.assertTrue(result)

    def test_user_exists1(self):
        result = self.db.user_exists('test_uname')
        self.assertTrue(result)

    def test_user_exists2(self):
        result = self.db.user_exists('unknown_username')
        self.assertFalse(result)
        

if __name__ == '__main__':
    unittest.main()

