import os
import tkinter as tk
from tkinter import ttk
from PIL import ImageTk, Image
from tkinter import messagebox
import configs
from sql_db.sql_connector import CredsDb

FNT = (configs.FNTFAMILY, configs.FNTSIZE+3, 'bold')


class Control(configs.CustomFrame):

    def __init__(self, *args, **kwargs):
        configs.CustomFrame.__init__(self)
        for i in range(1, 2):
            self.grid_rowconfigure(i, weight=1)
        for i in range(1):
            self.grid_columnconfigure(i, weight=1)

        headerLblFrm = configs.MyLabelFrame(self)
        headerLblFrm.grid(row=0, column=0, sticky='nsew')
        for i in range(1):
            headerLblFrm.grid_columnconfigure(i, weight=1)
        for i in range(1):
            headerLblFrm.grid_rowconfigure(i, weight=1)
        configs.MyButton(headerLblFrm, text='Back', command=self.goBack) \
                    .grid(pady=10)

        # --------------------------- BODY ------------------------------------
        bodyLblFrm = configs.MyLabelFrame(self)
        bodyLblFrm.grid(row=1, column=0, sticky='nsew', pady=20)
        for i in range(2):
            bodyLblFrm.grid_columnconfigure(i, weight=1)
        for i in range(2):
            bodyLblFrm.grid_rowconfigure(i, weight=1)
        
        # BACKGROUND IMAGE
        imgLbl = configs.MyLabel(bodyLblFrm)
        # 1397x568 = 2.45 # final on fullscreen
        tkImg = ImageTk.PhotoImage(image=Image.open(os.path.join(
                                                        configs.CURRDIR,
                                                        'perspectives',
                                                        'perspective0.jpg')))
        imgLbl.config(image=tkImg)
        imgLbl.image = tkImg
        imgLbl.place(x=0, y=0, relwidth=1, relheight=1, bordermode="outside")

        configs.MyButton(bodyLblFrm, text='Change Your Password', command=self.changePswd) \
                .grid(row=0, column=0, padx=20)
        configs.MyButton(bodyLblFrm, text='View movies', command=self.goToMovies) \
                .grid(row=0, column=1, padx=20)
        configs.MyButton(bodyLblFrm, text='Remove User', command=self.removeUser) \
                .grid(row=1, column=0, padx=20)
        configs.MyButton(bodyLblFrm, text='Change Users Status', command=self.changeUser) \
                .grid(row=1, column=1, padx=20)

        for frm in self.winfo_children():
            for widg in frm.winfo_children():
                if widg.winfo_class() == 'Button':
                    widg.config(width=configs.BTNWIDTH+7)

    def goBack(self, *args):
        self.destroy()
        import admin_win
        configs.ShowFrame(admin_win.AdminWin)

    def changePswd(self):
        self.destroy()
        import password_changer
        configs.ShowFrame(password_changer.Changer)

    def removeUser(self):
        self.destroy()
        configs.ShowFrame(UserRemover)

    def changeUser(self):
        self.destroy()
        configs.ShowFrame(UserStatusChanger)

    def goToMovies(self):
        self.destroy()
        import movie_form
        configs.ShowFrame(movie_form.MovieFormWin)


class UserStatusChanger(configs.CustomFrame):

    def __init__(self, *args, **kwargs):
        configs.CustomFrame.__init__(self)
        for i in range(1, 2):
            self.grid_rowconfigure(i, weight=1)
        for i in range(1):
            self.grid_columnconfigure(i, weight=1)
        self.showContents()

    def showContents(self):
        self.head()
        self.body()
        self.foot()

    def head(self):
        headerLblFrm = configs.MyLabelFrame(self)
        headerLblFrm.grid(row=0, column=0, sticky='nsew')
        for i in range(1):
            headerLblFrm.grid_columnconfigure(i, weight=1)
        for i in range(1):
            headerLblFrm.grid_rowconfigure(i, weight=1)
        configs.MyButton(headerLblFrm, text='Back', command=self.goBack) \
                    .grid(pady=30)

    def body(self):
        bodyLblFrm = configs.MyLabelFrame(self)
        bodyLblFrm.grid(row=1, column=0, sticky='nsew')
        for i in range(1):
            bodyLblFrm.grid_columnconfigure(i, weight=1)
        for i in range(4):
            bodyLblFrm.grid_rowconfigure(i, weight=1)

        # -------------- < Search widgets > -------------------------------
        searchLblFrm = configs.MyLabelFrame(bodyLblFrm, text='searcher')
        searchLblFrm.grid(sticky='ew') # varys
        searchLblFrm.grid_columnconfigure(2, weight=1)
        searchLblFrm.grid_columnconfigure(4, weight=1)

        configs.MyLabel(searchLblFrm, text='Search By:').grid(row=0, column=0)
        self.searchVar = tk.StringVar()
        searchBy = ['username', 'first_name', 'last_name', 'email', 'gender']
        configs.MyOptionMenu(searchLblFrm, self.searchVar, *searchBy) \
                .grid(row=0, column=1)
        self.searchVar.set(searchBy[0])
        self.searchBar = configs.MyEntry(searchLblFrm, bg=configs.SEARCHBGCOLOR,
                                            bd=4, justify=tk.CENTER)
        searchBtn = configs.MyButton(searchLblFrm, text='Search', width=7,
                                command=self.displaySearchResults)
        showAll = configs.MyButton(searchLblFrm, text='Show All',
                                    command=self.populateWithUsers)
        self.searchBar.insert(0, 'Search Here...')
        self.searchBar.bind('<1>', self.clearSearch)
        self.searchBar.bind('<Return>', self.displaySearchResults)
        self.searchBar.grid(row=0, column=2, sticky='ew')
        searchBtn.grid(row=0, column=3)
        showAll.grid(row=0, column=4)
        # -------------- < /Search widgets > -------------------------------

        treeLblFrm = configs.MyLabelFrame(bodyLblFrm, text='tree')
        treeLblFrm.grid(sticky='nsew', padx=50)
        for i in range(1):
            treeLblFrm.grid_columnconfigure(i, weight=1)
        for i in range(1):
            treeLblFrm.grid_rowconfigure(i, weight=1)
        self.currRowsInTree = []
        self.u = self.f = self.l = self.e = self.g = None
        self.tree = ttk.Treeview(treeLblFrm,
                                    columns=('num', 'uname', 'fname', 'lname',
                                                'email', 'gender'),
                                    show='headings')
        self.tree.column('num', width=100)
        self.tree.column('uname', width=200)
        self.tree.column('fname', width=200)
        self.tree.column('lname', width=200)
        self.tree.column('email', width=300)
        self.tree.column('gender', width=100)
        self.tree.heading('num', text='NO.', anchor='w')
        self.tree.heading('uname', text='Username', anchor='w',
                            command=self.sortByUserName)
        self.tree.heading('fname', text='First Name', anchor='w',
                            command=self.sortByFirstName)
        self.tree.heading('lname', text='Last name', anchor='w',
                            command=self.sortByLastName)
        self.tree.heading('email', text='Email', anchor='w',
                            command=self.sortByEmail)
        self.tree.heading('gender', text='Gender', anchor='w',
                            command=self.sortByGender)
        self.tree.grid(row=0, column=0, sticky='nsew')
        self.populateWithUsers()
        
        self.scrollY = ttk.Scrollbar(treeLblFrm, orient=tk.VERTICAL,
                                        command=self.tree.yview)
        self.scrollY.grid(row=0, column=1, sticky='ns')
        self.tree.config(yscrollcommand=self.scrollY.set)

        style = ttk.Style()
        style.theme_use('default')
        style.configure("Treeview.Heading", background="#979797",
                            foreground="Black", font=FNT)
        style.configure('Treeview', background='#474747',
                            fieldbackground='#474747', font=FNT)
        style.map('Treeview',
                    background=[('selected', '#101010')],
                    foreground=[('selected', 'white')])

    def foot(self):
        bottomLblFrm = configs.MyLabelFrame(self, text='bottom')
        bottomLblFrm.grid(row=2, column=0, pady=30, sticky='nsew')
        for i in range(1):
            bottomLblFrm.grid_columnconfigure(i, weight=1)
        for i in range(1):
            bottomLblFrm.grid_rowconfigure(i, weight=1)
        configs.MyButton(bottomLblFrm, text='Change Status', command=self.mainTask).grid()

        for widg in self.winfo_children():
            if widg.winfo_class() == 'Labelframe':
                for subWidg in widg.winfo_children():
                    subWidg.config(font=FNT)
                continue
            widg.config(font=FNT)

    def populateWithUsers(self):
        with CredsDb(tblName=configs.CREDSTABLE) as db:
            info = db.getAllUsersInfo()
        self.insertRowsInTree(rows=info)

    def insertRowsInTree(self, rows=None):
        self.tree.delete(*self.tree.get_children())
        self.currRowsInTree = rows
        for i, info in enumerate(rows, start=1):
            username = info[0] if info[0] is not None else 'N/A'
            fname = info[1] if info[1] is not None else 'N/A'
            lname = info[2] if info[2] is not None else 'N/A'
            email = info[3] if info[3] is not None else 'N/A'
            gender = info[4] if info[4] is not None else 'N/A'

            self.tree.insert(parent='', index='end',
                            values=(i, username, fname, lname, email, gender))

    def sortByUserName(self):
        infos = configs.insertionSortMap(self.currRowsInTree, ascending=self.u,
                                    key=lambda info: info[0])
        self.u = not self.u   # True is ascending; False is descending
        self.insertRowsInTree(rows=infos)

    def sortByFirstName(self):
        infos = configs.insertionSortMap(self.currRowsInTree, ascending=self.f,
                                    key=lambda info: info[1])
        self.f = not self.f   # True is ascending; False is descending
        self.insertRowsInTree(rows=infos)

    def sortByLastName(self):
        infos = configs.insertionSortMap(self.currRowsInTree, ascending=self.l,
                                    key=lambda info: info[2])
        self.l = not self.l   # True is ascending; False is descending
        self.insertRowsInTree(rows=infos)

    def sortByEmail(self):
        infos = configs.insertionSortMap(self.currRowsInTree, ascending=self.e,
                                    key=lambda info: info[3])
        self.e = not self.e   # True is ascending; False is descending
        self.insertRowsInTree(rows=infos)

    def sortByGender(self):
        infos = configs.insertionSortMap(self.currRowsInTree, ascending=self.g,
                                    key=lambda info: info[4])
        self.g = not self.g   # True is ascending; False is descending
        self.insertRowsInTree(rows=infos)

    def clearSearch(self, *args):
        print('clked on Search', self.searchBar.get())
        # seems no way to select the current contents
        self.searchBar.delete(0, tk.END)
        self.searchBar.bind('<1>', lambda x: None)

    def displaySearchResults(self, *args):
        searchTerm = self.searchBar.get()
        colName = self.searchVar.get()
        if searchTerm != '':
            with CredsDb(tblName=configs.CREDSTABLE) as db:
                matchingTitles = db.containing(colName=colName,
                                                searchExpr=searchTerm+'.*',
                                                useRegex=True)
            if not matchingTitles:
                messagebox.showerror(message='No results found.')
                return
            self.insertRowsInTree(rows=matchingTitles)

    def mainTask(self):
        if not self.tree.focus():
            messagebox.showerror(message='No username selected yet. Double click to select.')
            return
        selectedUser = self.tree.item(self.tree.focus())['values'][1]
        configs.logger.debug('User Selected is %s', selectedUser)

        if selectedUser == configs.CURRLOGGEDIN:
            messagebox.showinfo(message='Cannot change current user\'s status.')
            return

        with CredsDb(tblName=configs.CREDSTABLE) as db:
            db.changeUserStatus(selectedUser)

        messagebox.showinfo(message='Operation was successfull.')
        self.populateWithUsers()

    def goBack(self, *args):
        # self.destroy()
        configs.ShowFrame(Control)


class UserRemover(UserStatusChanger):

    def __init__(self):
        UserStatusChanger.__init__(self)

    def foot(self):
        bottomLblFrm = configs.MyLabelFrame(self, text='bottom')
        bottomLblFrm.grid(row=2, column=0, pady=30, sticky='nsew')
        for i in range(1):
            bottomLblFrm.grid_columnconfigure(i, weight=1)
        for i in range(1):
            bottomLblFrm.grid_rowconfigure(i, weight=1)
        configs.MyButton(bottomLblFrm, text='Remove', command=self.mainTask).grid()

        for widg in self.winfo_children():
            if widg.winfo_class() == 'Labelframe':
                for subWidg in widg.winfo_children():
                    subWidg.config(font=FNT)
                continue
            widg.config(font=FNT)

    def mainTask(self):
        if not self.tree.focus():
            messagebox.showerror(message='No username selected yet. Double click to select.')
            return
        selectedUser = self.tree.item(self.tree.focus())['values'][1]
        configs.logger.debug('User Selected is %s', selectedUser)

        if selectedUser == configs.CURRLOGGEDIN:
            messagebox.showinfo(message='Cannot remove current user.')
            return
        with CredsDb(tblName=configs.CREDSTABLE) as db:
            userRemoved = db.removeUser(selectedUser)
        if userRemoved:
            messagebox.showinfo(message='User Succssfully removed.')
            self.populateWithUsers()
        else:
            messagebox.showerror(message='User doesn\'t exists.')


if __name__ == '__main__':
    configs.CURRLOGGEDIN = 'admin1'
    configs.USERID = 1
    configs.ISADMIN = True
    configs.ROOT = configs.RootWin()
    configs.ROOT.attributes('-topmost', True)
    configs.ROOT.update()
    configs.ROOT.attributes('-topmost', False)
    configs.mainLogger()
    # configs.ShowFrame(Control, geometry='1397x720-2+0')
    configs.ShowFrame(UserRemover, geometry='1397x720-2+0')
    configs.ROOT.mainloop()