import tkinter as tk
# import os
import json
from sql_db.sql_connector import AppDb, CredsDb, UsersDb
import imdb_functions
import configs


# def removeInvalidCharInPath(p):
#     splitted = p.split(os.path.sep)
#     if 'windows' in platform.system().lower():
#         invalids = '\\/:?*<>|"'
#         for i in range(len(splitted)):
#             for invalid in invalids:
#                 splitted[i] = splitted[i].replace(invalid, '')

#     return (os.path.sep).join(splitted)

def createAllTables():
    with AppDb(tblName=configs.DBTABLE, create=True) as db:
        pass
    with AppDb(tblName=configs.USERDBTABLE, startPKFrom=configs.USERMOVPK, create=True) as db:
        pass
    with CredsDb(tblName=configs.CREDSTABLE, create=True) as db:
        pass
    with UsersDb(create=True) as db:
        pass

def updateSqlUsingPredefinedInfo():
    with AppDb(tblName=configs.DBTABLE) as db:
        if db.numOfRows() >= 20: return
        with open('20mov.json') as f:
            db.insertAllCols(json.loads(f.read()))

def fetchFromSQL(page, minRow=1):
    with AppDb(tblName=configs.DBTABLE) as db:
        # try every session to download all top movie info
        if db.numOfRows() < minRow: return None
        return db.getPage(page=page)

def getImdb250():
    try:
        moviesLst = imdb_functions.CustomImdb().get_top_rated()
    except Exception:
        return None

    with AppDb(tblName=configs.DBTABLE) as db:
        db.cardsDictToSql(moviesLst)
    return True


if __name__ == '__main__':
    # logger = logging.getLogger(__name__)
    # threading.Thread(target=paginateMovies).start()
    # cannot thread cuz gui may access PAGE1 before it consists anything
    # maybe if anything else is passed in first ShowFrame then can be threaded.
    
    createAllTables()
    configs.mainLogger()
    # configs.logger.setLevel('CRITICAL')

    configs.logger.debug('fetching from sql')
    # db should have at least 200 rows. if not try getting top250 movie from imdb
    PAGE1 = fetchFromSQL(page=1, minRow=200)
    if not PAGE1:
        configs.logger.debug('trying to download top 250 from imdb')
        # try_downloading_from_imdb
        if not getImdb250():
            # if dwnld failed update_SQLDB_with_predefined_cmd_using_offline_files
            configs.logger.warning('connection error. using json file.')
            updateSqlUsingPredefinedInfo()
        PAGE1 = fetchFromSQL(page=1)

    configs.ROOT = configs.RootWin()
    configs.ROOT.attributes('-topmost', True)
    configs.ROOT.update()
    configs.ROOT.attributes('-topmost', False)
    scrnW = configs.ROOT.winfo_screenwidth()
    scrnH = configs.ROOT.winfo_screenheight()

    # configs.CURRLOGGEDIN = 'admin1'
    # configs.USERID = 1
    # configs.ISADMIN = True
    import start_win
    configs.ShowFrame(start_win.StartWin, thisPage=PAGE1,
                        geometry=f'{scrnW}x{scrnH-70}-5+0', title='Movie Database')
    configs.ROOT.mainloop()
    
