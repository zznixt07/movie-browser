import tkinter as tk
from PIL import ImageTk, Image
import os
import threading
import queue
import requests
import configs
from sql_db.sql_connector import AppDb


class StartWin(configs.CustomFrame):
    page = 1

    def __init__(self, *args, **kwargs):
        configs.CustomFrame.__init__(self)
        # not scaling headerLblFrm cuz need max space for posters
        for i in range(1,2):
            self.grid_rowconfigure(i, weight=1)
        for i in range(1):
            self.grid_columnconfigure(i, weight=1)

        self.searchPage = 1
        # movies must be prepended to sql table to display user movies as well
        # as imdb movies.
        self.thisPage = kwargs['thisPage']
        # used to grid images later after fetching image and knowing when all
        # images have been grided. Each image grided -> coressponding labelframe
        # poped. Here, Label frames are used to group widgets.
        self.labelFrames = []
        # configs.logger.setLevel('CRITICAL')
        configs.logger.debug('PAGE IS %s', StartWin.page)
        
        headerLblFrm = configs.MyLabelFrame(self)
        headerLblFrm.grid(row=0, column=0, sticky='nsew')
        
        for i in range(7):
            headerLblFrm.grid_columnconfigure(i, weight=1)
        for i in range(1):
            headerLblFrm.grid_rowconfigure(i, weight=1)

        self.homeBtn = configs.MyButton(headerLblFrm, text='Home', command=self.goHome)
        # -------------- < Search widgets > -------------------------------
        self.searchLblFrm = configs.MyLabelFrame(headerLblFrm, text='searcher')
        self.searchLblFrm.grid_columnconfigure(2, weight=1)
        self.searchLblFrm.grid_columnconfigure(4, weight=1)

        configs.MyLabel(self.searchLblFrm, text='Search By:').grid(row=0, column=0)
        self.searchVar = tk.StringVar()
        configs.MyOptionMenu(self.searchLblFrm, self.searchVar, *configs.SEARCHBY) \
                        .grid(row=0, column=1)
        self.searchVar.set(configs.SEARCHBY[0])
        self.searchBar = configs.MyEntry(self.searchLblFrm, bg=configs.SEARCHBGCOLOR,
                                            bd=4, justify=tk.CENTER)
        searchBtn = configs.MyButton(self.searchLblFrm, text='Search', width=7,
                                command=self.displaySearchResults)
        showAll = configs.MyButton(self.searchLblFrm, text='Show All', command=self.goHome)
        self.searchBar.insert(0, 'Search Here.....')
        self.searchBar.bind('<1>', self.clearSearch)
        self.searchBar.bind('<Return>', self.displaySearchResults)
        self.searchBar.grid(row=0, column=2, columnspan=2, sticky='ew')
        searchBtn.grid(row=0, column=3)
        showAll.grid(row=0, column=4)
        # --------------- < /Search widgets > -------------------------
        self.adminBtn = configs.MyButton(headerLblFrm, text='Admin', command=self.goAdmin)
        self.userBtn = configs.MyButton(headerLblFrm, text='User', command=self.goUser)

        # ------------------- <body> ------------------------

        self.threadedGrid()

    def threadedGrid(self, searching=False):
        self.bodyLblFrm = configs.MyLabelFrame(self)
        self.bodyLblFrm.grid(row=1, column=0, sticky='nsew')
        for i in range(1, configs.NOFCOLS+1):
            self.bodyLblFrm.grid_columnconfigure(i, weight=1)
        for i in range(0, configs.NOFROWS+1):
            self.bodyLblFrm.grid_rowconfigure(i, weight=1)
        if searching:
            self.prevBtn = configs.MyButton(self.bodyLblFrm, text='<', width=1,
                                    height=configs.BTNHEIGHT+20,
                                    command=self.prevSearchPage)
            self.nextBtn = configs.MyButton(self.bodyLblFrm, text='>', width=1,
                                    height=configs.BTNHEIGHT+20,
                                    command=self.nextSearchPage)
        else:
            self.prevBtn = configs.MyButton(self.bodyLblFrm, text='<', width=1,
                                    height=configs.BTNHEIGHT+20,
                                    command=self.prevPage)
            self.nextBtn = configs.MyButton(self.bodyLblFrm, text='>', width=1,
                                    height=configs.BTNHEIGHT+20,
                                    command=self.nextPage)
            

        for i in range(len(self.thisPage)):
            lblFrm = configs.MyLabelFrame(self.bodyLblFrm, text='body')
            
            self.labelFrames.append(lblFrm)
            imgLbl = configs.MyLabel(lblFrm, wraplength=200, justify=tk.LEFT)
            movieInfoLbl = configs.MyLabel(lblFrm, fg='#f7f4e0', wraplength=200, justify=tk.LEFT)
            imgLbl.grid(row=0, column=0)
            movieInfoLbl.grid(row=1, column=0, sticky='w')

            l = configs.GRIDLAYOUT[i]
            lblFrm.grid(row=int(l[0]), column=int(l[1]))
            # when either the image or title is clicked. expand movie details.
            movieInfoLbl.bind('<1>', self.showFullInfo)
            imgLbl.bind('<1>', self.showFullInfo)

        self.sess = requests.Session()
        for movie in self.thisPage:
            url = movie['imgUrl']
            # this means data should alwz have pos -> so it must come from SQL
            file = str(movie['pos'])
            text = f"{movie['title']}\nrating: {movie['rating']}"
            t0 = threading.Thread(target=self.downloadImg, args=[url, file, text])
            t0.start()
        
        # t1 = threading.Thread(target=self.imagesPathManager)
        # t1.start()
        self.periodicCall()

    def periodicCall(self):
        '''
        1. check the queue
        2. check if all images are grided
        > keep repeating above instructions
        '''
        self.imagesPathManager()
        if not self.labelFrames:
            # if all images in label frames are gridded, then display buttons
            # and stop checking queue
            configs.logger.info('showing buttons')
            self.homeBtn.grid(row=0, column=0)
            self.searchLblFrm.grid(row=0, column=1, columnspan=4, sticky='ew')
            self.adminBtn.grid(row=0, column=5)
            self.userBtn.grid(row=0, column=6)

            self.prevBtn.grid(row=0, column=0, rowspan=2)
            self.nextBtn.grid(row=0, column=6, rowspan=2)
            self.sess.close()
            return # see above
        configs.ROOT.after(300, self.periodicCall)

    def showFullInfo(self, e, *args):
        # e.widget gives the curr clicked widget/label.
        # since textvariable stores tk.StringVar() it must be converted to str
        movieName = str(e.widget.master.winfo_children()[1]['textvariable']).split('\n')[0]
        # self.destroy() # should not destroy cuz of back button -> .lower()
        import full_movie
        configs.ShowFrame(full_movie.Info, movieName, dbTable=configs.DBTABLE)

    def clearSearch(self, *args):
        configs.logger.debug('clked on Search')
        # seems no way to select the current contents
        self.searchBar.delete(0, tk.END)
        self.searchBar.bind('<1>', lambda x: None)

    def displaySearchResults(self, *args, **kwargs):
        searchTerm = self.searchBar.get()
        colName = self.searchVar.get()
        if searchTerm != '':
            with AppDb(tblName=configs.DBTABLE) as db:
                fullInfo = db.fullMovInfoRegex(page=self.searchPage,
                                                colName=colName,
                                                searchExpr=searchTerm+'.*',
                                                useRegex=True)
            self.thisPage = fullInfo
            if not self.thisPage:
                from tkinter import messagebox
                messagebox.showerror(message='No results found.')
                return
            # self.bodyLblFrm.grid_forget()
            self.bodyLblFrm.destroy()
            self.threadedGrid(searching=True)
            return True

    def goHome(self):
        self.destroy()
        configs.logger.debug('Home Btn pressed')
        StartWin.page = 1
        with AppDb(tblName=configs.DBTABLE) as db:
            homePage = db.getPage(page=StartWin.page)
        configs.ShowFrame(StartWin, thisPage=homePage)

    def nextPage(self,):
        configs.logger.debug('next Btn pressed')
        StartWin.page += 1
        with AppDb(tblName=configs.DBTABLE) as db:
            nextPage = db.getPage(page=StartWin.page)
        if not nextPage:
            StartWin.page -= 1
            return
        else:
            self.destroy()
            configs.ShowFrame(StartWin, thisPage=nextPage)

    def prevPage(self, ):
        configs.logger.debug('prev Btn pressed')
        StartWin.page -= 1
        with AppDb(tblName=configs.DBTABLE) as db:
            prevPage = db.getPage(page=StartWin.page)
        if not prevPage:
            StartWin.page += 1
            return
        else:
            self.destroy()
            configs.ShowFrame(StartWin, thisPage=prevPage)

    def nextSearchPage(self,):
        self.searchPage += 1
        if not self.displaySearchResults():
            self.searchPage -= 1

    def prevSearchPage(self,):
        self.searchPage -= 1
        if not self.displaySearchResults():
            self.searchPage += 1

    def goAdmin(self):
        self.destroy()
        import admin_win
        configs.ShowFrame(admin_win.AdminWin)

    def goUser(self):
        self.destroy()
        import user_win
        with AppDb(tblName=configs.USERDBTABLE) as db:
            userPage = db.getPage(page=user_win.UserWin.page)
        configs.ShowFrame(user_win.UserWin, thisPage=userPage)

    def resizeImage(self, imgPath, name, ext):
        try:
            imgObj = Image.open(imgPath)
        except Exception:
            configs.logger.error('Invalid image. Deleting it.')
            os.remove(imgPath)
            return
        w, h = imgObj.size[0], imgObj.size[1]
        sizes = {'large': 268/h}
        for size in sizes.keys():
            file = f'{name}--{size}{ext}'
            if os.path.exists(file): continue
            configs.logger.debug('resizing %s', name)
            newImg = imgObj.resize((int(w * sizes[size]), int(h * sizes[size])))
            newImg.save(file)

    def imagesPathManager(self):
        while configs.IMAGESQUEUE.qsize():
        # while self.labelFrames:
            try:
                # if self.labelFrames: return
                imgPath, text = configs.IMAGESQUEUE.get(0)
                configs.logger.info('popping 1st labelFrame from %s length list', len(self.labelFrames))
                frm = self.labelFrames.pop(0)
                if imgPath is not None:
                    # download error
                    name, ext = os.path.splitext(imgPath)
                    name = name.split('--')[0]
                    # imgPath = name.split('--')[0] + '--medium' + ext
                    # images are grided as they are downloaded hence they will be 
                    # placed randomly first time. However after they are in db. they
                    # are placed in the order they were in. (descending ratings)
                    configs.logger.debug('gridding image %s', name[-10:])
                    self.resizeImage(imgPath, name, ext)
                    try:
                        tkImg = ImageTk.PhotoImage(image=Image.open(name + '--large' + ext))
                        frm.winfo_children()[0].config(image=tkImg)
                        frm.winfo_children()[0].image = tkImg
                    except Exception:
                        configs.logger.error('Invalid image. Deleting it.')
                        os.remove(imgPath)

                frm.winfo_children()[1].config(text=text.upper(), textvariable=text)
                configs.IMAGESQUEUE.task_done()
                configs.logger.debug('gridding done ---')
            except queue.Empty:
                pass

    def downloadImg(self, url, name, text, pathOnly=None):
        if url is None:
            configs.IMAGESQUEUE.put([None, text])
            return

        if not pathOnly: pathOnly = os.path.join(configs.CURRDIR, 'posters')
        os.makedirs(pathOnly, exist_ok=True)
        # WILL IMAGE ALWAYZ BE IN .jpg?? This will be used as download path.
        fullPath = os.path.join(pathOnly, name + '--original.jpg')

        for ext in ['.jpg', '.jpeg', '.png']:
            if os.path.exists(os.path.splitext(fullPath)[0] + ext):
                # return fullPath, name
                configs.logger.info('already dwnloaded. putting %s to image queue', name)
                configs.IMAGESQUEUE.put([os.path.splitext(fullPath)[0] + ext, text])
                return

        configs.logger.info('dwnlding and putting %s to image queue', name)
        # dwnldPath = Neutron.get(url, customName=name+'--original.jpg', customPath=pathOnly)
        try:
            r = self.sess.get(url, stream=True, verify=False)
        except Exception:
            configs.logger.warning('dwnlding %s failed!! ', name)
            configs.IMAGESQUEUE.put([None, text])
            return
        if r.status_code != 200: return
        # not required cuz imdbid is used for filename
        # dwnldPath = removeInvalidCharInPath(fullPath)
        with open(fullPath, 'wb') as f:
            for chunk in r.iter_content(chunk_size=1024*1024):
                f.write(chunk)

        configs.IMAGESQUEUE.put([fullPath, text])
        return

"""
class Poster:

    def __init__(self):
        self.imgPath = imgPath
        try:
            self.imgObj = Image.open(self.imgPath)
        except (FileNotFoundError, UnidentifiedImageError, ValueError, AttributeError):
            return
        self.name, self.ext = os.path.splitext(self.imgPath)
        self.name = self.name.split('--')[0]
        self.resizeImage()

        # mediumImg = Image.open(self.name + '--medium' + self.ext)
        ImageTk.PhotoImage.__init__(self, image=Image.open(f'{self.name}--{Poster.currSize}{self.ext}'))

        self.imgLbl = tk.Label(master=lblFrm, image=self)
        self.imgLbl.grid(row=0, column=0)
        Poster.imgLbls[Poster.indexes] = self.imgLbl
        Poster.indexes += 1
        self.aspectRatio = self.imgObj.size[0] / self.imgObj.size[1]

        # only bind to one labelFrame. cuz all have same height difference
        if not Poster.binded:
            Poster.binded = True
            lblFrm.bind('<Configure>', self.resizer)
            # SeaOfWindows.mainFrame.bind('<Configure>', self.resizer)


    def resizeImage(self):
        w, h = self.imgObj.size[0], self.imgObj.size[1]
        sizes = {'small': 80/h, 'medium': 160/h, 'large': 268/h}
        for size in sizes.keys():
            file = os.path.join(configs.CURRDIR, f'{self.name}--{size}{self.ext}')
            if os.path.exists(file): continue
            logging.debug('resizing %s', self.name)
            newImg = self.imgObj.resize((int(w * sizes[size]), int(h * sizes[size])))
            newImg.save(file)

    def resizer(self, event):
        '''
        ratioH = 1
        h = int(float(self.imgLbl.winfo_height() / ratioH))
        w = int(float(h * self.aspectRatio))
        # print(w,h)
        # self.imgLbl.config(width=w)
        # self.imgLbl.config(height=h)

        img = ImageTk.PhotoImage(image=self.imgObj.resize((w, h)))
        self.imgLbl.configure(image=img)
        self.imgLbl.image = img
        '''
        imgHeight = event.height
        logging.debug('current height is %s', imgHeight)
        logging.debug()
        if imgHeight < SCRNHGHT * 0.4:
            # if the poster is already small, dont redraw it!!
            if Poster.currSize == 'small': return
            Poster.currSize = 'small'
        elif imgHeight < SCRNHGHT * 0.65:
            if Poster.currSize == 'medium': return
            Poster.currSize = 'medium'
        else:
            if Poster.currSize == 'large': return
            Poster.currSize = 'large'
        print('changing size to', Poster.currSize)

        i = 0
        for img in StartWin.imgLst:
            name, ext = os.path.splitext(img)
            imgPath = f'{name.split("--")[0]}--{Poster.currSize}{ext}'
            try:
                tkImg = ImageTk.PhotoImage(image=Image.open(imgPath))
            except (FileNotFoundError, UnidentifiedImageError, ValueError, AttributeError):
                continue
            Poster.imgLbls[i].configure(image=tkImg)
            Poster.imgLbls[i].image = tkImg
            i += 1
"""


if __name__ == '__main__':
    configs.ROOT = configs.RootWin()
    configs.ROOT.attributes('-topmost', True)
    configs.ROOT.update()
    configs.ROOT.attributes('-topmost', False)
    with AppDb(tblName=configs.DBTABLE) as db:
        thisPage = db.getPage(page=1)
    configs.mainLogger()
    configs.ShowFrame(StartWin, geometry='1397x720-2+0', thisPage=thisPage)
    configs.ROOT.mainloop()

