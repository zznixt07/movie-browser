# import tkinter as tk
from PIL import ImageTk, Image
import os
import logging
from sql_db.sql_connector import AppDb
import configs


class AdminWin(configs.CustomFrame):
    
    def __init__(self, *args, **kwargs):
        configs.CustomFrame.__init__(self)
        # not scaling headerLblFrm cuz need max space for posters
        for i in range(1,2):
            self.grid_rowconfigure(i, weight=1)
        for i in range(1):
            self.grid_columnconfigure(i, weight=1)
        
        headerLblFrm = configs.MyLabelFrame(self)
        headerLblFrm.grid(row=0, column=0, sticky='ew')
        for i in range(8):
            headerLblFrm.grid_columnconfigure(i, weight=1)
        for i in range(1):
            headerLblFrm.grid_rowconfigure(i, weight=1)
        self.homeBtn = configs.MyButton(headerLblFrm, text='Home', command=self.goHome)
        self.profileLbl = configs.MyLabel(headerLblFrm, font=('Consolas', 14, 'bold'),
                                            fg='#000', bg='#fff', wraplength=100)
        self.homeBtn.grid(row=0, column=0, pady=10)
        if configs.CURRLOGGEDIN:
            self.profileLbl.config(text=configs.CURRLOGGEDIN)
            self.profileLbl.grid(row=0, column=7, sticky='e')

        bodyLblFrm = configs.MyLabelFrame(self)
        bodyLblFrm.grid(row=1, column=0, sticky='nsew')
        for i in range(3):
            bodyLblFrm.grid_columnconfigure(i, weight=1)
        for i in range(1):
            bodyLblFrm.grid_rowconfigure(i, weight=1)
        
         # BACKGROUND IMAGE
        imgLbl = configs.MyLabel(bodyLblFrm)
        # 1397x568 = 2.45 # final fullscreen
        tkImg = ImageTk.PhotoImage(image=Image.open(os.path.join(
                                                        configs.CURRDIR,
                                                        'perspectives',
                                                        'perspective2.jpg')))
        imgLbl.config(image=tkImg)
        imgLbl.image = tkImg
        imgLbl.place(x=0, y=0, relwidth=1, relheight=1, bordermode="outside")

        configs.MyButton(bodyLblFrm, text='Login', command=self.adminLogin) \
                        .grid(row=0, column=0)
        if configs.ISADMIN:
            configs.MyButton(bodyLblFrm, text='Admin Panel', command=self.adminPanel) \
                            .grid(row=0, column=1)
        configs.MyButton(bodyLblFrm, text='Sign Up', command=self.adminSignUp) \
                        .grid(row=0, column=2)

    def goHome(self):
        self.destroy()
        logging.debug('Home Btn pressed')
        # using class varaible, the page numbers are remembered and can be resumed
        import start_win
        with AppDb(tblName=configs.DBTABLE) as db:
            homePage = db.getPage(page=start_win.StartWin.page)
        configs.ShowFrame(start_win.StartWin, thisPage=homePage)

    def adminLogin(self):
        self.destroy()
        import admin_activity
        configs.ShowFrame(admin_activity.AdminLogin)

    def adminSignUp(self):
        self.destroy()
        import admin_activity
        configs.ShowFrame(admin_activity.AdminSignup)

    def adminPanel(self):
        self.destroy()
        import admin_control
        configs.ShowFrame(admin_control.Control)

if __name__ == '__main__':
    configs.ROOT = configs.RootWin()
    configs.ROOT.attributes('-topmost', True)
    configs.ROOT.update()
    configs.ROOT.attributes('-topmost', False)
    configs.mainLogger()
    configs.ShowFrame(AdminWin, geometry='1397x720-2+0')
    configs.ROOT.mainloop()