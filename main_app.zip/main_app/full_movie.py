import threading
import imdb_functions
from PIL import ImageTk, Image
import os
import configs
from sql_db.sql_connector import AppDb, UsersDb


class Info(configs.CustomFrame):
    allKeys = ['imdbId', 'totalRatedBy', 'year', 'genres', 'isSeries', 'start',
                'end', 'epNum', 'szNum', 'country', 'cast', 'plot', 'directors', 'writers']

    def __init__(self, movieName, dbTable=None):
        self.dbTable = dbTable
        configs.CustomFrame.__init__(self)
        for i in range(1, 2):
            self.grid_rowconfigure(i, weight=1)
        for i in range(1):
            self.grid_columnconfigure(i, weight=1)

        headerLblFrm = configs.MyLabelFrame(self)
        headerLblFrm.grid(row=0, column=0, sticky='nsew')
        for i in range(1):
            headerLblFrm.grid_columnconfigure(i, weight=1)
        headerLblFrm.grid_rowconfigure(0, weight=1)
        self.backBtn = configs.MyButton(headerLblFrm, text='Back',
                                        command=lambda: self.goBack(movieName))

        # --------------------------- BODY -----------------------------------
        self.bodyLblFrm = configs.MyLabelFrame(self, text='body')
        self.bodyLblFrm.grid(row=1, column=0, sticky='nsew')
        for i in range(1, 3):
            self.bodyLblFrm.grid_columnconfigure(i, weight=1)
        for i in range(1):
            self.bodyLblFrm.grid_rowconfigure(i, weight=1)

        info = configs.changeToStr(self.movieAllDetails(movieName))
        self.pos = info['pos']
        self.newerRating = None
        if configs.CURRLOGGEDIN:
            self.givenRating = self.getRatingOnMovieByUser(configs.CURRLOGGEDIN,
                                                            movieName)
        else:
            self.givenRating = None
        if not info: return
        posterPath = os.path.join(configs.CURRDIR, 'posters',
                                    str(self.pos) + '--original.jpg')
        if not os.path.exists(posterPath):
            posterPath = os.path.join(configs.CURRDIR, 'jpgs', 'no-poster.jpg')
        imgLbl = configs.MyLabel(self.bodyLblFrm)
        imgLbl.grid(row=0, column=0, sticky='nsew')
        imgObj = Image.open(posterPath)
        w, h = imgObj.size[0], imgObj.size[1]
        imgObj = imgObj.resize((480, int((480/w) * h)))
        tkImg = ImageTk.PhotoImage(image=imgObj)
        imgLbl.config(image=tkImg)
        imgLbl.image = tkImg

        self.gridInfo(info)
        self.threaderReq(info)

    def gridInfo(self, info):
        infoLblFrm = configs.MyLabelFrame(self.bodyLblFrm, text='info')
        infoLblFrm.grid(row=0, column=1, columnspan=2, sticky='nsew')
        for i in range(1):
            infoLblFrm.grid_columnconfigure(i, weight=1)
        for i in range(15):
            infoLblFrm.grid_rowconfigure(i, weight=1)

        plotArea = configs.MyLabelFrame(infoLblFrm,
                            font=(configs.FNTFAMILY, configs.FNTSIZE+4, 'bold'))
        plotArea.config(text='plot', labelanchor='nw', bd=1)
        plotArea.grid(padx=50, sticky='nsew')
        configs.MyLabel(plotArea, text=info['plot'], wraplength=700).grid(padx=20)

        configs.MyLabel(infoLblFrm, text=f"Title: {info['title']}",
                        font=(configs.FNTFAMILY, configs.FNTSIZE+4, 'bold underline')) \
                    .grid(padx=50, sticky='w')
        configs.MyLabel(infoLblFrm, text=f"Year Released: {info['year']}") \
                    .grid(padx=50, sticky='w')
        configs.MyLabel(infoLblFrm, text=f"Rating: {info['rating']}") \
                    .grid(padx=50, sticky='w')
        configs.MyLabel(infoLblFrm, text=f"Total rated by: {info['totalRatedBy']}") \
                    .grid(padx=50, sticky='w')
        configs.MyLabel(infoLblFrm, text='Genres: '+info['genres']) \
                    .grid(padx=50, sticky='w')
        configs.MyLabel(infoLblFrm, text='Cast: '+info['cast']) \
                    .grid(padx=50, sticky='w')
        
        configs.MyLabel(infoLblFrm, text='Directors: '+info['directors']) \
                    .grid(padx=50, sticky='w')
        configs.MyLabel(infoLblFrm, text='Writers: '+info['writers']) \
                    .grid(padx=50, sticky='w')
        configs.MyLabel(infoLblFrm, text='Country: '+info['country']) \
                    .grid(padx=50, sticky='w')
        configs.MyLabel(infoLblFrm,
                        text='Type: ' + ('Tv- Series' if info['isSeries'] else 'Movie')) \
                    .grid(padx=50, sticky='w')
        if info['isSeries']:
            configs.MyLabel(infoLblFrm, text=f"Year Finished: {info['end']}") \
                        .grid(padx=50, sticky='w')
            configs.MyLabel(infoLblFrm, text=f"Number of Seasons: {info['szNum']}") \
                        .grid(padx=50, sticky='w')
            configs.MyLabel(infoLblFrm, text=f"Number of Episodes: {info['epNum']}") \
                        .grid(padx=50, sticky='w')

        self.ratingArea = configs.MyLabelFrame(infoLblFrm)
        self.ratingArea.config(text='Your Rating', labelanchor='nw', bd=1,
                            font=(configs.FNTFAMILY, configs.FNTSIZE+4, 'bold'))
        self.ratingArea.grid(padx=50, sticky='nsew')
        
        self.btns = []
        if not self.givenRating:
            self.fillFullStars(end=0)
            self.fillEmptyStars(start=0)
        else:
            self.fillFullStars()
            self.fillEmptyStars()
        
        for widg in infoLblFrm.winfo_children()[2:]:
            widg.config(font=(configs.FNTFAMILY, configs.FNTSIZE+4, 'bold'))

        for widg in plotArea.winfo_children():
            widg.config(font=(configs.FNTFAMILY, configs.FNTSIZE+2, 'italic'))
        self.infoLblFrm = infoLblFrm

    def fillFullStars(self, end=None):
        # no start cuz full stars always begin from 0
        if end is None:
            end = int(round(self.givenRating, 0))
        else:
            end = end
        filledStar = Image.open(os.path.join(configs.CURRDIR, 'jpgs', 'filled_star_16.png'))
        filledStarImg = ImageTk.PhotoImage(image=filledStar)
        for col in range(end):
            starBtn = configs.MyButton(self.ratingArea, image=filledStarImg,
                                        bg=configs.SEARCHBGCOLOR, height=20,
                                        width=30, relief='flat', activebackground='#989898',
                                        command=lambda col=col: self.ratingButtons(col))
                        
            starBtn.image = filledStarImg
            starBtn.grid(row=0, column=col, padx=4)
            self.btns.append(starBtn)


    def fillEmptyStars(self, start=None):
        # no end cuz it always ends upto 10
        if start is None:
            start = int(round(self.givenRating, 0))
        else:
            start = start
        emptyStar = Image.open(os.path.join(configs.CURRDIR, 'jpgs', 'empty_star_16.png'))
        emptyStarImg = ImageTk.PhotoImage(image=emptyStar)
        for col in range(start, 10):
            starBtn = configs.MyButton(self.ratingArea, image=emptyStarImg,
                                        bg=configs.SEARCHBGCOLOR, height=20,
                                        width=30, relief='flat', activebackground='#989898',
                                        command=lambda col=col: self.ratingButtons(col))
            
            starBtn.image = emptyStarImg
            starBtn.grid(row=0, column=col, padx=4)
            self.btns.append(starBtn)


    def ratingButtons(self, col, *args):
        # print(e.widget.grid_info())['column']
        # print(f'{col=}')
        self.newerRating = col + 1
        filledStar = Image.open(os.path.join(configs.CURRDIR, 'jpgs', 'filled_star_16.png'))
        filledStarImg = ImageTk.PhotoImage(image=filledStar)
        for i in range(col+1):
            self.btns[i].config(image=filledStarImg)
            self.btns[i].image = filledStarImg

        emptyStar = Image.open(os.path.join(configs.CURRDIR, 'jpgs', 'empty_star_16.png'))
        emptyStarImg = ImageTk.PhotoImage(image=emptyStar)
        for i in range(col+1, len(self.btns)):
            self.btns[i].config(image=emptyStarImg)
            self.btns[i].image = emptyStarImg            

    def threaderReq(self, info):
        configs.logger.debug('checking whether to thread')
        # we find out if the info is already downloaded by looking at '' columns
        # assumption is made that at least > 0 column is filled after info is downloaded
        if list(info.values()).count('') >= 13 and info['imdbId']:
            configs.logger.info('uh oh Threading')
            threading.Thread(target=self.getInfo, args=[info['imdbId']]).start()
        else:
            configs.logger.debug('OK Not threading')
            self.backBtn.grid(columnspan=3)

    def getInfo(self, imdbId):
        try:
            imdb = imdb_functions.CustomImdb()
            info = imdb_functions.getFullDetails(imdb.get_title_auxiliary(imdbId))
        except Exception as e:
            configs.logger.error(e)
            self.backBtn.grid(columnspan=3)
            return
        self.backBtn.grid(columnspan=3)
        self.infoLblFrm.destroy()
        self.gridInfo(configs.changeToStr(info))

        with AppDb(tblName=configs.DBTABLE) as db:
            if db.detailedDictToSql({**{k: info[k] for k in self.allKeys},
                                    **{'pos': self.pos}}):
                configs.logger.debug('succesfully updated mov database')

    def getRatingOnMovieByUser(self, username, title):
        configs.logger.debug('getting rating by user: %s', username)
        with UsersDb() as db:
            rating = db.getUserRatingsOnMovie(username, title)

        if not rating: return 0
        return rating

    def movieAllDetails(self, movieName):
        configs.logger.debug('%s', movieName)
        with AppDb(tblName=self.dbTable) as db:
            return db.dictFromTitle(movieName)

    def goBack(self, movieName):
        if configs.USERID and (self.newerRating is not None):
            print(f'{self.newerRating=}')
            with UsersDb() as db:
                # we put users imdb rating too to users_rating table not imdb
                db.putRatingByUser(configs.USERID, movieName, self.newerRating)
                avgRating = db.averageRating(movieName)

            # do not write imdb movies to user_added_movs
            if configs.USERDBTABLE == self.dbTable:
                with AppDb(tblName=configs.USERDBTABLE) as db:
                    db.putAvgRating(movieName, avgRating)
        # since the home windows was not destroyed, destroying this frame will
        # just make home appear. and cannot lower self after destroying self obv..
        self.destroy()
        # self.lower()

